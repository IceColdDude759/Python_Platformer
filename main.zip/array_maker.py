import pickle

##############################################################################
####################### FILE/LEVEl TO EDIT HERE ##############################
level = 4
##############################################################################
##############################################################################

height=640
width=640*5
block=32
no_of_row=int(width/block)
no_of_column=int(height/block)

no_of_tile=height//block
middle = no_of_tile//2
##for me lists are in [[20 elements
#],......]
print(no_of_column)
print(no_of_row)
array=[]
temp_array=[]

#making a empty array
for row in range(0,no_of_row):

	for column in range(0,no_of_column):
		temp_array.append(0)
	array.append(temp_array)
	temp_array=[]
#
j=0
for row in array:
	i=0
	for column in row:
		
		#making the useless block dirt
		if j <= middle:
			row[i]=1
		#making last 5 dirt vertical
		elif i>no_of_column-5:
			row[i]=1
		#making last 2 dirt horizontal
		elif j>no_of_row-3:
			row[i]=1

		i+=1
		
	j+=1
print(middle)
with open(f"data{level}.ani","wb") as f:
	pickle.dump(array,f)

